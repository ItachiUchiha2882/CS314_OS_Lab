## Usage instructions

- Run using 'bash run.sh <input_file>' where <input_file> can be input1.txt 
  or input2.txt or input3.txt or input4.txt or input5.txt.