#!/bin/bash

# This script is used to run the application
g++ 200010004.cpp -o 200010004
./200010004 $1
