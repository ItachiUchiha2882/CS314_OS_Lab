if(rmp->priority >= USER_Q){
    printf("Minix (200010004): PID %d swapped in\n", _ENDPOINT_P(rmp->endpoint));
}