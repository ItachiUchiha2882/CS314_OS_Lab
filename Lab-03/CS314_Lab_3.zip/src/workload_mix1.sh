#!/bin/sh
./arithoh.sh &
./fstime.sh &
wait
