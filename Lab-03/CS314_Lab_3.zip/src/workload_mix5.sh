#!/bin/sh
./arithoh.sh &
./pipe.sh &
wait
