#!/bin/sh
./arithoh.sh &
./spawn.sh &
wait
