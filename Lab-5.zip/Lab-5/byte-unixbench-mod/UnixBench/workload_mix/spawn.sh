#!/bin/sh
time ../pgms/spawn
echo "spawn completed"
echo "---"
