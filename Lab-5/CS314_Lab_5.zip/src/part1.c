printf("Minix : Allotted Quantum: %d ms\n               
        Minix : Used Quantum: %d ms\n",                      
        p->p_quantum_size_ms, p->p_quantum_size_ms -      
               cpu_time_2_ms(p->p_cpu_time_left));
