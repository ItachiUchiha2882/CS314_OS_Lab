rmp->priority -= 1; /* higher priority */
